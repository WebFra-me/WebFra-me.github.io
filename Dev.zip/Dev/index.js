$(document).ready(function() {
  var fs = require('fs');
  const wd_homedir = require('os').homedir();
  var wd_dir = wd_homedir + '/WebDesk-top/';
document.getElementById("apps").innerHTML = '';
apps = fs.readdirSync(wd_dir + "Apps/");
for (i = 0; i < apps.length; i++) {
  if(apps[i] != ".DS_Store"){
  app = fs.readFileSync(wd_dir + "Apps/" + apps[i] + "/Admin/app.json");
  oapp = JSON.parse(app);
    document.getElementById("apps").innerHTML += '<div class="card"><div class="card-body"><h4 class="card-title">' + oapp.title + '</h4><a class="btn btn-primary" href="layout.html?wd_app=Dev&wd_sec=dir&app=' + apps[i] + '"><b>Open</b></a></div></div>';
  }
}
$("#nf1").click(function(){
  var filen = document.getElementById("napp").value;
  var dir = wd_dir + "Apps/" + filen;
  if (!fs.existsSync(dir)){
    fs.mkdirSync(dir);
    fs.mkdirSync(dir + '/Admin');
    fs.writeFile(dir + '/Admin/app.json', '{"title":"' + filen + '"}', function (err) {
      if (err) throw err;
        console.log('Saved!');
      });
    fs.writeFile(dir + '/index.html', '<div class="container"></div>', function (err) {
      if (err) throw err;
        console.log('Saved!');
      });
    fs.writeFile(dir + '/index.js', '$(document).ready(function() { const wd_homedir = require("os").homedir(); var wd_dir = wd_homedir + "/WebDesk-top/"; var wd_url_string = window.location.href; var wd_url = new URL(wd_url_string); var wd_app = wd_url.searchParams.get("wd_app"); var wd_sec = wd_url.searchParams.get("wd_sec");}); //var img = document.createElement("img"); img.src = wd_dir + "Apps/" + wd_app + "/flower.jpg"; var src = document.getElementById("img"); src.appendChild(img);', function (err) {
      if (err) throw err;
        console.log('Saved!');
      });
    fs.writeFile(dir + '/style.css', 'html, body{font-family: "Courier New", Courier, Monospace;} h1,h2,h3{font-family: "Arial Rounded MT", Arial, Helvetica, sans-serif;} .jumbotron{color: #ffffff; background-color: #1161D9;} .card{ color: #ffffff; background-color: #D98911}', function (err) {
      if (err) throw err;
        console.log('Saved!');
      });
      fs.writeFile(dir + '/head.html', '<title>WebDesk-top</title><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> //bootstrap, vue.js, phaser.io, tinymce, fontawesome-free, jequery, & jquery-ui are pre loded', function (err) {
        if (err) throw err;
          console.log('Saved!');
        });
      window.location.assign('layout.html?wd_app=Dev&wd_sec=page&app=' + filen + '&page=index.html');
  }
  else{
    window.alert("This App Already Exists");
  }
});
});
