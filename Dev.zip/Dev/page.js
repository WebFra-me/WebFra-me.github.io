$(document).ready(function() {
  var fs = require('fs');
  const wd_homedir = require('os').homedir();
  var wd_dir = wd_homedir + '/WebDesk-top/';
  var url_string = window.location.href;
  var url = new URL(url_string);
  var id = url.searchParams.get("app");
  var page = url.searchParams.get("page");
  document.getElementById("path").innerHTML = id + "/" + page;
  var path = wd_dir + "Apps/" + id + "/" + page;
  bob = fs.readFileSync(path);
  document.getElementById("con").value = bob;
  $("#link").click(function(){
    window.location.assign('layout.html?wd_app=Dev&wd_sec=dir&app=' + id);
  });
  $("#delete").click(function(){
    fs.unlink(path, function (err) {
      if (err) throw err;
      console.log('File deleted!');
    });
    window.location.assign('layout.html?wd_app=Dev&wd_sec=dir&app=' + id);
  });
$("#save").click(function(){
  save = document.getElementById("con").value;
  fs.writeFile(path, save, function (err) {
    if (err) throw err;
      console.log('Save!');
      alert('Saved!');
    });
});
});
